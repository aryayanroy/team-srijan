# Running the sample application

### Step 1
Open `sample.php` and fill the account details:
```php
$public_key = 'your_public_key';
$your_private_key = 'your_private_key';
$url_end_point = 'https://ik.imagekit.io/demo';
```

### Step 2:
Run the `sample.php` file.
```bash
php sample.php
```