<?php

echo "\n\n------------------------------------------------------------";
echo "\n\n----------------- URL GENERATION SAMPLES -------------------";
echo "\n\n------------------------------------------------------------";
echo "\n";

include_once('resize_crop_other_common_transformations.php');
include_once('overlay.php');
include_once('image_enhancement_and_color_manipulation.php');
include_once('chained_transformations.php');
include_once('signed_url.php');